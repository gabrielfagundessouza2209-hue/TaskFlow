// TASKFLOW - Front-end integrado à API Flask/MySQL
const $ = id => document.getElementById(id);

let currentUser = null;
let data = { lists: [], tasks: [] };
let currentFilter = "all";
let currentList = "";
let editingId = null;
let showCompleted = false;

async function api(url, options = {}) {
    const response = await fetch(url, {
        credentials: "same-origin",
        headers: {
            "Content-Type": "application/json",
            ...(options.headers || {})
        },
        ...options
    });

    const result = response.status === 204 ? {} : await response.json().catch(() => ({}));
    if (!response.ok) {
        throw new Error(result.erro || result.mensagem || "Não foi possível concluir a operação.");
    }
    return result;
}

function showMessage(message, success = false) {
    $("authMessage").textContent = message;
    $("authMessage").style.color = success ? "#5ed6a0" : "#ff9999";
}

function mostrarLogin() {
    $("login").classList.remove("oculto");
    $("cadastro").classList.add("oculto");
    $("abaLogin").classList.add("ativa");
    $("abaCadastro").classList.remove("ativa");
    showMessage("");
}

function mostrarCadastro() {
    $("cadastro").classList.remove("oculto");
    $("login").classList.add("oculto");
    $("abaCadastro").classList.add("ativa");
    $("abaLogin").classList.remove("ativa");
    showMessage("");
}

$("abaLogin").addEventListener("click", mostrarLogin);
$("abaCadastro").addEventListener("click", mostrarCadastro);
$("irCadastro").addEventListener("click", mostrarCadastro);
$("irLogin").addEventListener("click", mostrarLogin);

$("cadastroForm").addEventListener("submit", async event => {
    event.preventDefault();
    const nome = $("nome").value.trim();
    const email = $("emailCadastro").value.trim().toLowerCase();
    const senha = $("senhaCadastro").value;
    const confirmar = $("confirmarSenha").value;

    if (senha.length < 8) {
        showMessage("A senha precisa ter pelo menos 8 caracteres.");
        return;
    }
    if (senha !== confirmar) {
        showMessage("As senhas não são iguais.");
        return;
    }

    try {
        await api("/api/cadastro", {
            method: "POST",
            body: JSON.stringify({ nome, email, senha })
        });
        $("cadastroForm").reset();
        mostrarLogin();
        $("emailLogin").value = email;
        showMessage("Conta criada! Agora você pode entrar.", true);
    } catch (error) {
        showMessage(error.message);
    }
});

$("loginForm").addEventListener("submit", async event => {
    event.preventDefault();
    const email = $("emailLogin").value.trim().toLowerCase();
    const senha = $("senhaLogin").value;
    try {
        const result = await api("/api/login", {
            method: "POST",
            body: JSON.stringify({ email, senha })
        });
        currentUser = result.usuario;
        $("loginForm").reset();
        await openDashboard();
    } catch (error) {
        showMessage(error.message);
    }
});

async function openDashboard() {
    $("authScreen").classList.add("oculto");
    $("dashboard").classList.remove("oculto");
    $("userName").textContent = currentUser.nome;
    $("userAvatar").textContent = currentUser.nome.charAt(0).toUpperCase();
    await loadData();
    render();
}

async function loadData() {
    const result = await api("/api/dados");
    data = {
        lists: result.lists || [],
        tasks: result.tasks || []
    };
    if (data.lists.length === 0) {
        // O backend cria automaticamente uma lista padrão.
        data = await api("/api/dados");
    }
    currentList = data.lists[0]?.id || "";
}

$("btnLogout").addEventListener("click", async () => {
    try {
        await api("/api/logout", { method: "POST", body: "{}" });
    } catch (error) {
        console.error(error);
    }
    currentUser = null;
    data = { lists: [], tasks: [] };
    $("dashboard").classList.add("oculto");
    $("authScreen").classList.remove("oculto");
    $("sidebar").classList.remove("open");
    $("loginForm").reset();
    mostrarLogin();
});

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
    })[char]);
}

function renderLists() {
    $("listNavigation").innerHTML = data.lists.map(list => {
        const count = data.tasks.filter(task =>
            task.listId === list.id && !task.completed
        ).length;
        return `
            <button class="list-option ${
                currentFilter === "list" && currentList === list.id ? "active" : ""
            }" data-list="${escapeHTML(list.id)}">
                <span>▣ &nbsp; ${escapeHTML(list.name)}</span>
                <small>${count}</small>
            </button>`;
    }).join("");

    $("taskList").innerHTML = data.lists.map(list =>
        `<option value="${escapeHTML(list.id)}">${escapeHTML(list.name)}</option>`
    ).join("");

    document.querySelectorAll("[data-list]").forEach(button => {
        button.addEventListener("click", () => {
            currentFilter = "list";
            currentList = button.dataset.list;
            render();
        });
    });
}

$("btnAddList").addEventListener("click", async () => {
    const name = prompt("Digite o nome da nova lista:");
    if (!name || !name.trim()) return;
    try {
        const list = await api("/api/listas", {
            method: "POST",
            body: JSON.stringify({ name: name.trim() })
        });
        data.lists.push(list);
        currentFilter = "list";
        currentList = list.id;
        render();
    } catch (error) {
        alert(error.message);
    }
});

function getVisibleTasks() {
    let tasks = [...data.tasks];
    if (currentFilter === "starred") {
        tasks = tasks.filter(task => task.starred);
    } else if (currentFilter === "list") {
        tasks = tasks.filter(task => task.listId === currentList);
    }
    const search = $("searchInput").value.trim().toLowerCase();
    if (search) {
        tasks = tasks.filter(task =>
            task.name.toLowerCase().includes(search) ||
            task.description.toLowerCase().includes(search)
        );
    }
    return tasks;
}

function taskHTML(task) {
    const date = task.date
        ? new Date(task.date + "T12:00:00").toLocaleDateString("pt-BR")
        : "";
    return `
        <article class="task-item ${task.completed ? "completed" : ""}">
            <input class="task-check" type="checkbox"
                data-complete="${escapeHTML(task.id)}"
                ${task.completed ? "checked" : ""}
                aria-label="Concluir tarefa">
            <div class="task-info">
                <div class="task-name">${escapeHTML(task.name)}</div>
                ${task.description ? `<div class="task-description">${escapeHTML(task.description)}</div>` : ""}
                ${date ? `<span class="task-date">◷ ${date}</span>` : ""}
                <span class="task-priority ${task.priority}">
                    ${task.priority === "alta" ? "● Alta prioridade" :
                      task.priority === "baixa" ? "● Baixa prioridade" : ""}
                </span>
            </div>
            <div class="task-actions">
                <button class="${task.starred ? "starred" : ""}"
                    data-star="${escapeHTML(task.id)}" title="Favoritar">
                    ${task.starred ? "★" : "☆"}
                </button>
                <button data-edit="${escapeHTML(task.id)}" title="Editar">✎</button>
                <button data-delete="${escapeHTML(task.id)}" title="Excluir">⋮</button>
            </div>
        </article>`;
}

function render() {
    renderLists();
    const tasks = getVisibleTasks();
    const pending = tasks.filter(task => !task.completed);
    const completed = tasks.filter(task => task.completed);
    $("pendingTasks").innerHTML = pending.map(taskHTML).join("");
    $("completedTasks").innerHTML = completed.map(taskHTML).join("");
    $("pendingCount").textContent = pending.length;
    $("completedCount").textContent = completed.length;
    $("completedTasks").hidden = !showCompleted;
    $("completedArrow").textContent = showCompleted ? "▾" : "▸";
    $("taskCount").textContent =
        `${pending.length} tarefas em andamento · ${completed.length} concluídas`;

    const list = data.lists.find(item => item.id === currentList);
    const names = {
        all: "Todas as tarefas",
        starred: "Com estrela",
        list: list?.name || "Lista"
    };
    $("currentTitle").textContent = names[currentFilter];
    $("pageTitle").textContent = names[currentFilter];
    document.querySelectorAll(".nav-item").forEach(button => {
        button.classList.toggle("active", button.dataset.filter === currentFilter);
    });
    $("emptyState").hidden = tasks.length > 0;
    $("btnAddInline").hidden = currentFilter === "starred";

    document.querySelectorAll("[data-complete]").forEach(input => {
        input.addEventListener("change", async () => {
            const task = data.tasks.find(t => t.id === input.dataset.complete);
            if (!task) return;
            const updated = { ...task, completed: input.checked };
            try {
                await salvarTarefa(task.id, updated);
                Object.assign(task, updated);
                render();
            } catch (error) {
                alert(error.message);
                render();
            }
        });
    });

    document.querySelectorAll("[data-star]").forEach(button => {
        button.addEventListener("click", async () => {
            const task = data.tasks.find(t => t.id === button.dataset.star);
            if (!task) return;
            const updated = { ...task, starred: !task.starred };
            try {
                await salvarTarefa(task.id, updated);
                Object.assign(task, updated);
                render();
            } catch (error) {
                alert(error.message);
            }
        });
    });

    document.querySelectorAll("[data-edit]").forEach(button => {
        button.addEventListener("click", () => openModal(button.dataset.edit));
    });

    document.querySelectorAll("[data-delete]").forEach(button => {
        button.addEventListener("click", async () => {
            const id = button.dataset.delete;
            const task = data.tasks.find(t => t.id === id);
            if (!task || !confirm(`Excluir "${task.name}"?`)) return;
            try {
                await api(`/api/tarefas/${encodeURIComponent(id)}`, {
                    method: "DELETE"
                });
                data.tasks = data.tasks.filter(t => t.id !== id);
                render();
            } catch (error) {
                alert(error.message);
            }
        });
    });
}

async function salvarTarefa(id, task) {
    return api(`/api/tarefas/${encodeURIComponent(id)}`, {
        method: "PUT",
        body: JSON.stringify(task)
    });
}

function openModal(id = null) {
    editingId = id;
    const task = data.tasks.find(t => t.id === id);
    $("taskForm").reset();
    $("modalTitle").textContent = task ? "Editar tarefa" : "Nova tarefa";
    if (task) {
        $("taskName").value = task.name;
        $("taskDescription").value = task.description;
        $("taskDate").value = task.date;
        $("taskPriority").value = task.priority;
        $("taskList").value = task.listId;
    } else {
        $("taskList").value =
            currentFilter === "list" ? currentList : data.lists[0]?.id || "";
    }
    $("taskModal").hidden = false;
    $("taskName").focus();
}

function closeModal() {
    $("taskModal").hidden = true;
    editingId = null;
}

$("taskForm").addEventListener("submit", async event => {
    event.preventDefault();
    const name = $("taskName").value.trim();
    if (!name) return;
    const taskData = {
        name,
        description: $("taskDescription").value.trim(),
        date: $("taskDate").value,
        priority: $("taskPriority").value,
        listId: $("taskList").value,
        completed: false,
        starred: false
    };

    try {
        if (editingId) {
            const existing = data.tasks.find(t => t.id === editingId);
            const updated = { ...existing, ...taskData };
            await salvarTarefa(editingId, updated);
            Object.assign(existing, updated);
        } else {
            const result = await api("/api/tarefas", {
                method: "POST",
                body: JSON.stringify(taskData)
            });
            data.tasks.push({ id: result.id, ...taskData });
        }
        closeModal();
        render();
    } catch (error) {
        alert(error.message);
    }
});

function createTask() { openModal(); }
$("btnNewTask").addEventListener("click", createTask);
$("btnNewTask2").addEventListener("click", createTask);
$("btnAddInline").addEventListener("click", createTask);
$("btnEmptyTask").addEventListener("click", createTask);
$("closeModal").addEventListener("click", closeModal);
$("cancelModal").addEventListener("click", closeModal);
$("taskModal").addEventListener("click", event => {
    if (event.target === $("taskModal")) closeModal();
});

document.querySelectorAll(".nav-item").forEach(button => {
    button.addEventListener("click", () => {
        currentFilter = button.dataset.filter;
        render();
    });
});

$("completedToggle").addEventListener("click", () => {
    showCompleted = !showCompleted;
    render();
});

$("btnSearch").addEventListener("click", () => {
    $("searchBox").hidden = !$("searchBox").hidden;
    if (!$("searchBox").hidden) {
        $("searchInput").focus();
    } else {
        $("searchInput").value = "";
        render();
    }
});
$("searchInput").addEventListener("input", render);
$("btnTheme").addEventListener("click", () => document.body.classList.toggle("light"));
$("btnMenu").addEventListener("click", () => $("sidebar").classList.toggle("open"));

async function restaurarSessao() {
    try {
        const result = await api("/api/me");
        currentUser = result.usuario;
        await openDashboard();
    } catch {
        currentUser = null;
    }
}
restaurarSessao();
