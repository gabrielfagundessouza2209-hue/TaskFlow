import os
from datetime import timedelta

from dotenv import load_dotenv
load_dotenv()

from flask import Flask, jsonify, render_template, request, session
from mysql.connector import IntegrityError, Error

from conexao.database import conectar
from seguranca import gerar_hash, verificar_senha

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("TASKFLOW_SECRET_KEY", "troque-esta-chave-em-producao"),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("TASKFLOW_HTTPS", "0") == "1",
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
)


def resposta_erro(mensagem, status):
    return jsonify({"erro": mensagem}), status


def usuario_atual_id():
    return session.get("usuario_id")


@app.route("/")
def inicio():
    return render_template("index.html")


@app.get("/api/me")
def api_me():
    usuario_id = usuario_atual_id()
    if not usuario_id:
        return resposta_erro("Não autenticado.", 401)

    conexao = conectar()
    if conexao is None:
        return resposta_erro("Não foi possível conectar ao banco de dados.", 500)
    cursor = None
    try:
        cursor = conexao.cursor(dictionary=True)
        cursor.execute(
            "SELECT id, nome, email FROM usuarios WHERE id = %s",
            (usuario_id,),
        )
        usuario = cursor.fetchone()
        if not usuario:
            session.clear()
            return resposta_erro("Sessão inválida.", 401)
        usuario["id"] = str(usuario["id"])
        return jsonify({"usuario": usuario})
    except Error:
        app.logger.exception("Erro ao consultar usuário atual")
        return resposta_erro("Erro ao consultar usuário.", 500)
    finally:
        if cursor:
            cursor.close()
        conexao.close()


@app.post("/api/cadastro")
def api_cadastro():
    dados = request.get_json(silent=True) or {}
    nome = str(dados.get("nome", "")).strip()
    email = str(dados.get("email", "")).strip().lower()
    senha = dados.get("senha", "")

    if not nome or not email or not isinstance(senha, str):
        return resposta_erro("Preencha todos os campos.", 400)
    if len(nome) > 120 or len(email) > 254:
        return resposta_erro("Nome ou e-mail excede o tamanho permitido.", 400)
    if len(senha) < 8:
        return resposta_erro("A senha deve ter pelo menos 8 caracteres.", 400)

    conexao = conectar()
    if conexao is None:
        return resposta_erro("Não foi possível conectar ao banco de dados.", 500)
    cursor = None
    try:
        cursor = conexao.cursor()
        cursor.execute(
            """
            INSERT INTO usuarios (nome, email, senha_hash)
            VALUES (%s, %s, %s)
            """,
            (nome, email, gerar_hash(senha)),
        )
        conexao.commit()
        return jsonify({"mensagem": "Conta criada com sucesso!"}), 201
    except IntegrityError:
        conexao.rollback()
        return resposta_erro("Este e-mail já está cadastrado.", 409)
    except Error:
        conexao.rollback()
        app.logger.exception("Erro ao cadastrar usuário")
        return resposta_erro("Não foi possível concluir o cadastro.", 500)
    finally:
        if cursor:
            cursor.close()
        conexao.close()


@app.post("/api/login")
def api_login():
    dados = request.get_json(silent=True) or {}
    email = str(dados.get("email", "")).strip().lower()
    senha = dados.get("senha", "")
    if not email or not isinstance(senha, str):
        return resposta_erro("Informe e-mail e senha.", 400)

    conexao = conectar()
    if conexao is None:
        return resposta_erro("Não foi possível conectar ao banco de dados.", 500)
    cursor = None
    try:
        cursor = conexao.cursor(dictionary=True)
        cursor.execute(
            "SELECT id, nome, email, senha_hash FROM usuarios WHERE email = %s",
            (email,),
        )
        usuario = cursor.fetchone()
        if not usuario or not verificar_senha(senha, usuario["senha_hash"]):
            return resposta_erro("E-mail ou senha incorretos.", 401)

        session.clear()
        session.permanent = True
        session["usuario_id"] = int(usuario["id"])
        return jsonify({
            "mensagem": "Login realizado com sucesso!",
            "usuario": {
                "id": str(usuario["id"]),
                "nome": usuario["nome"],
                "email": usuario["email"],
            },
        })
    except Error:
        app.logger.exception("Erro ao autenticar usuário")
        return resposta_erro("Não foi possível realizar o login.", 500)
    finally:
        if cursor:
            cursor.close()
        conexao.close()


@app.post("/api/logout")
def api_logout():
    session.clear()
    return jsonify({"mensagem": "Sessão encerrada."})


def carregar_dados_usuario(conexao, usuario_id):
    cursor = conexao.cursor(dictionary=True)
    try:
        cursor.execute(
            "SELECT id, nome FROM listas WHERE usuario_id = %s ORDER BY id",
            (usuario_id,),
        )
        listas = [{"id": str(row["id"]), "name": row["nome"]} for row in cursor.fetchall()]

        cursor.execute(
            """
            SELECT id, lista_id, nome, descricao, data_limite,
                   prioridade, concluida, favorita
            FROM tarefas
            WHERE usuario_id = %s
            ORDER BY id DESC
            """,
            (usuario_id,),
        )
        tarefas = []
        for row in cursor.fetchall():
            tarefas.append({
                "id": str(row["id"]),
                "listId": str(row["lista_id"]) if row["lista_id"] is not None else "",
                "name": row["nome"],
                "description": row["descricao"] or "",
                "date": row["data_limite"].isoformat() if row["data_limite"] else "",
                "priority": row["prioridade"],
                "completed": bool(row["concluida"]),
                "starred": bool(row["favorita"]),
            })
        return {"lists": listas, "tasks": tarefas}
    finally:
        cursor.close()


@app.get("/api/dados")
def api_dados():
    usuario_id = usuario_atual_id()
    if not usuario_id:
        return resposta_erro("Não autenticado.", 401)
    conexao = conectar()
    if conexao is None:
        return resposta_erro("Não foi possível conectar ao banco de dados.", 500)
    cursor = None
    try:
        cursor = conexao.cursor()
        cursor.execute(
            "INSERT INTO listas (usuario_id, nome) "
            "SELECT %s, 'Minhas tarefas' "
            "WHERE NOT EXISTS (SELECT 1 FROM listas WHERE usuario_id = %s)",
            (usuario_id, usuario_id),
        )
        conexao.commit()
        return jsonify(carregar_dados_usuario(conexao, usuario_id))
    except Error:
        conexao.rollback()
        app.logger.exception("Erro ao carregar dados do TaskFlow")
        return resposta_erro("Não foi possível carregar seus dados.", 500)
    finally:
        if cursor:
            cursor.close()
        conexao.close()


@app.post("/api/listas")
def api_criar_lista():
    usuario_id = usuario_atual_id()
    if not usuario_id:
        return resposta_erro("Não autenticado.", 401)
    dados = request.get_json(silent=True) or {}
    nome = str(dados.get("name", "")).strip()
    if not nome or len(nome) > 100:
        return resposta_erro("Informe um nome de lista de até 100 caracteres.", 400)

    conexao = conectar()
    if conexao is None:
        return resposta_erro("Não foi possível conectar ao banco de dados.", 500)
    cursor = None
    try:
        cursor = conexao.cursor()
        cursor.execute(
            "INSERT INTO listas (usuario_id, nome) VALUES (%s, %s)",
            (usuario_id, nome),
        )
        conexao.commit()
        return jsonify({"id": str(cursor.lastrowid), "name": nome}), 201
    except Error:
        conexao.rollback()
        app.logger.exception("Erro ao criar lista")
        return resposta_erro("Não foi possível criar a lista.", 500)
    finally:
        if cursor:
            cursor.close()
        conexao.close()


def validar_tarefa(dados):
    nome = str(dados.get("name", "")).strip()
    descricao = str(dados.get("description", "")).strip()
    data = dados.get("date") or None
    prioridade = dados.get("priority", "normal")
    lista_id = dados.get("listId") or None
    if not nome or len(nome) > 180:
        raise ValueError("O nome da tarefa é obrigatório e deve ter até 180 caracteres.")
    if prioridade not in ("baixa", "normal", "alta"):
        raise ValueError("Prioridade inválida.")
    if data:
        from datetime import date
        date.fromisoformat(data)
    return nome, descricao, data, prioridade, lista_id


@app.post("/api/tarefas")
def api_criar_tarefa():
    usuario_id = usuario_atual_id()
    if not usuario_id:
        return resposta_erro("Não autenticado.", 401)
    dados = request.get_json(silent=True) or {}
    try:
        nome, descricao, data, prioridade, lista_id = validar_tarefa(dados)
    except (ValueError, TypeError):
        return resposta_erro("Dados da tarefa inválidos.", 400)

    conexao = conectar()
    if conexao is None:
        return resposta_erro("Não foi possível conectar ao banco de dados.", 500)
    cursor = None
    try:
        cursor = conexao.cursor()
        if lista_id:
            cursor.execute(
                "SELECT id FROM listas WHERE id = %s AND usuario_id = %s",
                (lista_id, usuario_id),
            )
            if not cursor.fetchone():
                return resposta_erro("Lista não encontrada.", 404)
        cursor.execute(
            """
            INSERT INTO tarefas
                (usuario_id, lista_id, nome, descricao, data_limite, prioridade)
            VALUES (%s, %s, %s, %s, %s, %s)
            """,
            (usuario_id, lista_id, nome, descricao, data, prioridade),
        )
        conexao.commit()
        return jsonify({"id": str(cursor.lastrowid)}), 201
    except Error:
        conexao.rollback()
        app.logger.exception("Erro ao criar tarefa")
        return resposta_erro("Não foi possível criar a tarefa.", 500)
    finally:
        if cursor:
            cursor.close()
        conexao.close()


@app.put("/api/tarefas/<int:tarefa_id>")
def api_atualizar_tarefa(tarefa_id):
    usuario_id = usuario_atual_id()
    if not usuario_id:
        return resposta_erro("Não autenticado.", 401)
    dados = request.get_json(silent=True) or {}
    try:
        nome, descricao, data, prioridade, lista_id = validar_tarefa(dados)
    except (ValueError, TypeError):
        return resposta_erro("Dados da tarefa inválidos.", 400)

    concluida = bool(dados.get("completed", False))
    favorita = bool(dados.get("starred", False))
    conexao = conectar()
    if conexao is None:
        return resposta_erro("Não foi possível conectar ao banco de dados.", 500)
    cursor = None
    try:
        cursor = conexao.cursor()
        if lista_id:
            cursor.execute(
                "SELECT id FROM listas WHERE id = %s AND usuario_id = %s",
                (lista_id, usuario_id),
            )
            if not cursor.fetchone():
                return resposta_erro("Lista não encontrada.", 404)
        cursor.execute(
            """
            UPDATE tarefas
            SET lista_id = %s, nome = %s, descricao = %s, data_limite = %s,
                prioridade = %s, concluida = %s, favorita = %s
            WHERE id = %s AND usuario_id = %s
            """,
            (lista_id, nome, descricao, data, prioridade, concluida,
             favorita, tarefa_id, usuario_id),
        )
        if cursor.rowcount == 0:
            cursor.execute(
                "SELECT id FROM tarefas WHERE id = %s AND usuario_id = %s",
                (tarefa_id, usuario_id),
            )
            if not cursor.fetchone():
                return resposta_erro("Tarefa não encontrada.", 404)
        conexao.commit()
        return jsonify({"mensagem": "Tarefa atualizada."})
    except Error:
        conexao.rollback()
        app.logger.exception("Erro ao atualizar tarefa")
        return resposta_erro("Não foi possível atualizar a tarefa.", 500)
    finally:
        if cursor:
            cursor.close()
        conexao.close()


@app.delete("/api/tarefas/<int:tarefa_id>")
def api_excluir_tarefa(tarefa_id):
    usuario_id = usuario_atual_id()
    if not usuario_id:
        return resposta_erro("Não autenticado.", 401)
    conexao = conectar()
    if conexao is None:
        return resposta_erro("Não foi possível conectar ao banco de dados.", 500)
    cursor = None
    try:
        cursor = conexao.cursor()
        cursor.execute(
            "DELETE FROM tarefas WHERE id = %s AND usuario_id = %s",
            (tarefa_id, usuario_id),
        )
        if cursor.rowcount == 0:
            return resposta_erro("Tarefa não encontrada.", 404)
        conexao.commit()
        return jsonify({"mensagem": "Tarefa excluída."})
    except Error:
        conexao.rollback()
        app.logger.exception("Erro ao excluir tarefa")
        return resposta_erro("Não foi possível excluir a tarefa.", 500)
    finally:
        if cursor:
            cursor.close()
        conexao.close()


if __name__ == "__main__":
    app.run(debug=True)
