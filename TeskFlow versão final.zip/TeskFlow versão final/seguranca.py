from werkzeug.security import generate_password_hash, check_password_hash


def gerar_hash(senha: str) -> str:
    """Gera um hash scrypt com salt automático; nunca armazene a senha pura."""
    return generate_password_hash(senha, method="scrypt")


def verificar_senha(senha: str, senha_hash: str) -> bool:
    """Compara a senha digitada com o hash persistido no banco."""
    return check_password_hash(senha_hash, senha)
