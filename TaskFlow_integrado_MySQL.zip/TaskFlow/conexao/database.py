import os
import mysql.connector
from mysql.connector import Error


def conectar():
    """Abre uma conexão com o banco TaskFlow."""
    try:
        return mysql.connector.connect(
            host=os.getenv("DB_HOST", "127.0.0.1"),
            port=int(os.getenv("DB_PORT", "3307")),
            user=os.getenv("DB_USER", "root"),
            password=os.getenv("DB_PASSWORD", ""),
            database=os.getenv("DB_NAME", "taskflow"),
            charset="utf8mb4",
            use_unicode=True,
        )
    except Error as erro:
        print(f"Erro ao conectar ao banco: {erro}")
        return None
