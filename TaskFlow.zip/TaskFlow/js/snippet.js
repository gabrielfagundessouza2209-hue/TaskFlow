
// ==========================================
// TASKFLOW - SISTEMA PRINCIPAL
// ==========================================

const $ = id => document.getElementById(id);

const ACCOUNTS_KEY = "taskflow_accounts";
const SESSION_KEY = "taskflow_session";

let currentUser = null;
let data = { lists: [], tasks: [] };
let currentFilter = "all";
let currentList = "";
let editingId = null;
let showCompleted = false;

// ==========================================
// FUNÇÕES DE ARMAZENAMENTO
// ==========================================

function getAccounts() {
    try {
        return JSON.parse(localStorage.getItem(ACCOUNTS_KEY)) || [];
    } catch {
        return [];
    }
}

function saveAccounts(accounts) {
    localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
}

function userStorageKey() {
    return "taskflow_data_" + currentUser.email;
}

function saveData() {
    localStorage.setItem(userStorageKey(), JSON.stringify(data));
}

function loadData() {
    try {
        const saved = JSON.parse(localStorage.getItem(userStorageKey()));

        if (saved && Array.isArray(saved.lists) && Array.isArray(saved.tasks)) {
            data = saved;
        } else {
            data = { lists: [], tasks: [] };
        }
    } catch {
        data = { lists: [], tasks: [] };
    }

    if (data.lists.length === 0) {
        data.lists.push({
            id: "minhas",
            name: "Minhas tarefas"
        });
        saveData();
    }

    currentList = data.lists[0].id;
}

// ==========================================
// LOGIN E CADASTRO
// ==========================================

function showMessage(message, success = false) {
    $("authMessage").textContent = message;
    $("authMessage").style.color = success ? "#5ed6a0" : "#ff9999";
}

function mostrarLogin() {
    $("login").classList.remove("oculto");
    $("cadastro").classList.add("oculto");

    $("abaLogin").classList.add("ativa");
    $("abaCadastro").classList.remove("ativa");

    showMessage("");
}

function mostrarCadastro() {
    $("cadastro").classList.remove("oculto");
    $("login").classList.add("oculto");

    $("abaCadastro").classList.add("ativa");
    $("abaLogin").classList.remove("ativa");

    showMessage("");
}

$("abaLogin").addEventListener("click", mostrarLogin);
$("abaCadastro").addEventListener("click", mostrarCadastro);
$("irCadastro").addEventListener("click", mostrarCadastro);
$("irLogin").addEventListener("click", mostrarLogin);

// CADASTRAR CONTA

$("cadastroForm").addEventListener("submit", event => {
    event.preventDefault();

    const nome = $("nome").value.trim();
    const email = $("emailCadastro").value.trim().toLowerCase();
    const senha = $("senhaCadastro").value;
    const confirmar = $("confirmarSenha").value;

    if (senha.length < 6) {
        showMessage("A senha precisa ter pelo menos 6 caracteres.");
        return;
    }

    if (senha !== confirmar) {
        showMessage("As senhas não são iguais.");
        return;
    }

    const accounts = getAccounts();

    if (accounts.some(user => user.email === email)) {
        showMessage("Este e-mail já está cadastrado.");
        return;
    }

    accounts.push({
        nome,
        email,
        senha
    });

    saveAccounts(accounts);

    $("cadastroForm").reset();

    mostrarLogin();
    $("emailLogin").value = email;

    showMessage("Conta criada! Agora você pode entrar.", true);
});

// ENTRAR

$("loginForm").addEventListener("submit", event => {
    event.preventDefault();

    const email = $("emailLogin").value.trim().toLowerCase();
    const senha = $("senhaLogin").value;

    const accounts = getAccounts();

    const user = accounts.find(account =>
        account.email === email && account.senha === senha
    );

    if (!user) {
        showMessage("E-mail ou senha incorretos.");
        return;
    }

    currentUser = user;

    sessionStorage.setItem(SESSION_KEY, user.email);

    $("loginForm").reset();

    openDashboard();
});

// ==========================================
// ABRIR PAINEL
// ==========================================

function openDashboard() {
    $("authScreen").classList.add("oculto");
    $("dashboard").classList.remove("oculto");

    $("userName").textContent = currentUser.nome;
    $("userAvatar").textContent = currentUser.nome.charAt(0).toUpperCase();

    loadData();
    render();
}

// SAIR DA CONTA

$("btnLogout").addEventListener("click", () => {
    sessionStorage.removeItem(SESSION_KEY);

    currentUser = null;
    data = { lists: [], tasks: [] };

    $("dashboard").classList.add("oculto");
    $("authScreen").classList.remove("oculto");

    $("sidebar").classList.remove("open");
    $("loginForm").reset();

    mostrarLogin();
});

// ==========================================
// LISTAS
// ==========================================

function renderLists() {
    $("listNavigation").innerHTML = data.lists.map(list => {
        const count = data.tasks.filter(task =>
            task.listId === list.id && !task.completed
        ).length;

        return `
            <button class="list-option ${
                currentFilter === "list" && currentList === list.id
                ? "active" : ""
            }" data-list="${escapeHTML(list.id)}">

                <span>▣ &nbsp; ${escapeHTML(list.name)}</span>
                <small>${count}</small>
            </button>
        `;
    }).join("");

    $("taskList").innerHTML = data.lists.map(list =>
        `<option value="${escapeHTML(list.id)}">${escapeHTML(list.name)}</option>`
    ).join("");

    document.querySelectorAll("[data-list]").forEach(button => {
        button.addEventListener("click", () => {
            currentFilter = "list";
            currentList = button.dataset.list;
            render();
        });
    });
}

// CRIAR NOVA LISTA

$("btnAddList").addEventListener("click", () => {
    const name = prompt("Digite o nome da nova lista:");

    if (!name || !name.trim()) return;

    data.lists.push({
        id: crypto.randomUUID(),
        name: name.trim()
    });

    currentFilter = "list";
    currentList = data.lists[data.lists.length - 1].id;

    saveData();
    render();
});

// ==========================================
// TAREFAS
// ==========================================

function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    })[char]);
}

function getVisibleTasks() {
    let tasks = [...data.tasks];

    if (currentFilter === "starred") {
        tasks = tasks.filter(task => task.starred);
    } else if (currentFilter === "list") {
        tasks = tasks.filter(task => task.listId === currentList);
    }

    const search = $("searchInput").value.trim().toLowerCase();

    if (search) {
        tasks = tasks.filter(task =>
            task.name.toLowerCase().includes(search) ||
            task.description.toLowerCase().includes(search)
        );
    }

    return tasks;
}

// MONTAR VISUAL DA TAREFA

function taskHTML(task) {
    const date = task.date
        ? new Date(task.date + "T12:00:00").toLocaleDateString("pt-BR")
        : "";

    return `
        <article class="task-item ${task.completed ? "completed" : ""}">

            <input
                class="task-check"
                type="checkbox"
                data-complete="${escapeHTML(task.id)}"
                ${task.completed ? "checked" : ""}
                aria-label="Concluir tarefa"
            >

            <div class="task-info">

                <div class="task-name">
                    ${escapeHTML(task.name)}
                </div>

                ${task.description ? `
                    <div class="task-description">
                        ${escapeHTML(task.description)}
                    </div>
                ` : ""}

                ${date ? `
                    <span class="task-date">◷ ${date}</span>
                ` : ""}

                <span class="task-priority ${task.priority}">
                    ${task.priority === "alta" ? "● Alta prioridade" :
                      task.priority === "baixa" ? "● Baixa prioridade" : ""}
                </span>

            </div>

            <div class="task-actions">

                <button
                    class="${task.starred ? "starred" : ""}"
                    data-star="${escapeHTML(task.id)}"
                    title="Favoritar">
                    ${task.starred ? "★" : "☆"}
                </button>

                <button data-edit="${escapeHTML(task.id)}" title="Editar">✎</button>

                <button data-delete="${escapeHTML(task.id)}" title="Excluir">⋮</button>

            </div>

        </article>
    `;
}

// ATUALIZAR PAINEL

function render() {
    renderLists();

    const tasks = getVisibleTasks();

    const pending = tasks.filter(task => !task.completed);
    const completed = tasks.filter(task => task.completed);

    $("pendingTasks").innerHTML = pending.map(taskHTML).join("");
    $("completedTasks").innerHTML = completed.map(taskHTML).join("");

    $("pendingCount").textContent = pending.length;
    $("completedCount").textContent = completed.length;

    $("completedTasks").hidden = !showCompleted;

    $("completedArrow").textContent = showCompleted ? "▾" : "▸";

    $("taskCount").textContent =
        `${pending.length} tarefas em andamento · ${completed.length} concluídas`;

    const list = data.lists.find(item => item.id === currentList);

    const names = {
        all: "Todas as tarefas",
        starred: "Com estrela",
        list: list?.name || "Lista"
    };

    $("currentTitle").textContent = names[currentFilter];
    $("pageTitle").textContent = names[currentFilter];

    document.querySelectorAll(".nav-item").forEach(button => {
        button.classList.toggle(
            "active",
            button.dataset.filter === currentFilter
        );
    });

    $("emptyState").hidden = tasks.length > 0;

    $("btnAddInline").hidden = currentFilter === "starred";

    // CONCLUIR TAREFA

    document.querySelectorAll("[data-complete]").forEach(input => {
        input.addEventListener("change", () => {
            const task = data.tasks.find(t => t.id === input.dataset.complete);

            if (!task) return;

            task.completed = input.checked;

            saveData();
            render();
        });
    });

    // FAVORITAR

    document.querySelectorAll("[data-star]").forEach(button => {
        button.addEventListener("click", () => {
            const task = data.tasks.find(t => t.id === button.dataset.star);

            if (!task) return;

            task.starred = !task.starred;

            saveData();
            render();
        });
    });

    // EDITAR

    document.querySelectorAll("[data-edit]").forEach(button => {
        button.addEventListener("click", () => {
            openModal(button.dataset.edit);
        });
    });

    // EXCLUIR

    document.querySelectorAll("[data-delete]").forEach(button => {
        button.addEventListener("click", () => {
            const id = button.dataset.delete;
            const task = data.tasks.find(t => t.id === id);

            if (task && confirm(`Excluir "${task.name}"?`)) {
                data.tasks = data.tasks.filter(t => t.id !== id);

                saveData();
                render();
            }
        });
    });
}

// ==========================================
// MODAL
// ==========================================

function openModal(id = null) {
    editingId = id;

    const task = data.tasks.find(t => t.id === id);

    $("taskForm").reset();

    $("modalTitle").textContent =
        task ? "Editar tarefa" : "Nova tarefa";

    if (task) {
        $("taskName").value = task.name;
        $("taskDescription").value = task.description;
        $("taskDate").value = task.date;
        $("taskPriority").value = task.priority;
        $("taskList").value = task.listId;
    } else {
        $("taskList").value =
            currentFilter === "list" ? currentList : data.lists[0]?.id || "";
    }

    $("taskModal").hidden = false;
    $("taskName").focus();
}

function closeModal() {
    $("taskModal").hidden = true;
    editingId = null;
}

$("taskForm").addEventListener("submit", event => {
    event.preventDefault();

    const name = $("taskName").value.trim();

    if (!name) return;

    const taskData = {
        name,
        description: $("taskDescription").value.trim(),
        date: $("taskDate").value,
        priority: $("taskPriority").value,
        listId: $("taskList").value
    };

    if (editingId) {
        const task = data.tasks.find(t => t.id === editingId);

        if (task) {
            Object.assign(task, taskData);
        }
    } else {
        data.tasks.push({
            id: crypto.randomUUID(),
            ...taskData,
            completed: false,
            starred: false
        });
    }

    saveData();
    closeModal();
    render();
});

// ==========================================
// EVENTOS DOS BOTÕES
// ==========================================

function createTask() {
    openModal();
}

$("btnNewTask").addEventListener("click", createTask);
$("btnNewTask2").addEventListener("click", createTask);
$("btnAddInline").addEventListener("click", createTask);
$("btnEmptyTask").addEventListener("click", createTask);

$("closeModal").addEventListener("click", closeModal);
$("cancelModal").addEventListener("click", closeModal);

$("taskModal").addEventListener("click", event => {
    if (event.target === $("taskModal")) closeModal();
});

// FILTROS

document.querySelectorAll(".nav-item").forEach(button => {
    button.addEventListener("click", () => {
        currentFilter = button.dataset.filter;
        render();
    });
});

// CONCLUÍDAS RECOLHÍVEIS

$("completedToggle").addEventListener("click", () => {
    showCompleted = !showCompleted;
    render();
});

// PESQUISA

$("btnSearch").addEventListener("click", () => {
    $("searchBox").hidden = !$("searchBox").hidden;

    if (!$("searchBox").hidden) {
        $("searchInput").focus();
    } else {
        $("searchInput").value = "";
        render();
    }
});

$("searchInput").addEventListener("input", render);

// ALTERNAR TEMA

$("btnTheme").addEventListener("click", () => {
    document.body.classList.toggle("light");
});

// MENU RESPONSIVO

$("btnMenu").addEventListener("click", () => {
    $("sidebar").classList.toggle("open");
});

// ==========================================
// RESTAURAR SESSÃO
// ==========================================

const savedEmail = sessionStorage.getItem(SESSION_KEY);

if (savedEmail) {
    const user = getAccounts().find(account => account.email === savedEmail);

    if (user) {
        currentUser = user;
        openDashboard();
    } else {
        sessionStorage.removeItem(SESSION_KEY);
    }
}
